export const metadata = {
  title: "Auth | Growly",
};

export default function AuthLayout({ children }) {
  return (
    <div className="h-screen">
      {children}
    </div>
  );
}


